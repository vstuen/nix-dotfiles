-- vim-suda: provides SudaRead and SudaWrite
return {
  'lambdalisue/vim-suda',
  version = '*',
}
