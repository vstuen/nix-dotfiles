return {
  'sindrets/diffview.nvim',
}
