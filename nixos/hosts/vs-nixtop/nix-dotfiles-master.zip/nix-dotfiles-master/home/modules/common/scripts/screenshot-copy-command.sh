#!/usr/bin/env bash
wl-copy -t image/png